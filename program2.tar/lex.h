// Shaya Wolf
// COSC5785 - Compilers 
// Program 2
// lex.h
// 9/9/2017

#ifndef LEX_H
#define LEX_H

#include"attributes.h"
#include<iostream>

extern attributes *atts;

#endif
